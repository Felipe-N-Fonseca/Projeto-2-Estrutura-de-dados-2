package SRC;
class calc{
    public static int max(int a, int b){
        if(a > b)return a;
        return b;
    }
}
